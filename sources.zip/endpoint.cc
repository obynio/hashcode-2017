#include "endpoint.hh"

Endpoint::Endpoint(int id_, int cost_, int nb_cache_)
{ 
  id = id_;
  cost = cost_;
  nb_cache = nb_cache_;
}


